package com.example.tamline;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

public class signupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }

    public void setText(View view) {
        final EditText editTextName = findViewById(R.id.inputName);
        final String textValueName = editTextName.getText().toString();

        final EditText editTextEmail = findViewById(R.id.inputEmail);
        final String textValueEmail = editTextEmail.getText().toString();

        final EditText editTextNumber = findViewById(R.id.inputNumber);
        final String textValueNumber = editTextNumber.getText().toString();

        final EditText editTextPassword = findViewById(R.id.inputPassword);
        final String textValuePassword = editTextPassword.getText().toString();

        final EditText editTextConfirmPassword = findViewById(R.id.inputConfirmPassword);
        final String textValueConfirmPassword = editTextConfirmPassword.getText().toString();

        if (TextUtils.isEmpty(textValueName)) {
            editTextName.setError("Silahkan Isi Nama");
            editTextName.requestFocus();
        } else if (TextUtils.isEmpty(textValueEmail)) {
            editTextEmail.setError("Silahkan Isi Email");
            editTextEmail.requestFocus();
        } else if (TextUtils.isEmpty(textValueNumber)) {
            editTextNumber.setError("Silahkan Isi Nomor Telepon");
            editTextNumber.requestFocus();
        } else if (TextUtils.isEmpty(textValuePassword)) {
            editTextPassword.setError("Silahkan Isi Kata Sandi");
            editTextPassword.requestFocus();
        } else if (TextUtils.isEmpty(textValueConfirmPassword)) {
            editTextConfirmPassword.setError("Silahkan Isi Konfirmasi Kata Sandi");
            editTextConfirmPassword.requestFocus();
        }
    }
}